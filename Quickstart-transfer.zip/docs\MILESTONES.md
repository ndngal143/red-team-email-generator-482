# Semester Milestones

Use this backlog as the project framework. Each milestone has prototype TODOs in the code and a suggested deliverable for the semester.

## Milestone 1: Authorization And Access Control

- TODO: Add user accounts and login.
- TODO: Add roles for admin, campaign author, reviewer, and viewer.
- TODO: Replace the prototype checkbox with stored authorization approvals.
- TODO: Log who generated, reviewed, exported, and launched each draft.
- Deliverable: Access-control design plus working login-gated prototype.

## Milestone 2: Campaign And Scenario Templates

- TODO: Create approved scenario templates by department and risk theme.
- TODO: Add reviewer notes, legal/HR approval fields, and campaign owner metadata.
- TODO: Block free-form scenarios unless a reviewer approves them.
- TODO: Add template IDs to generation logs.
- Deliverable: Scenario-template library and approval workflow mock.

## Milestone 3: Prompt Governance And Output Quality

- TODO: Version prompts and store prompt/version metadata with every generated draft.
- TODO: Add regression test cases for allowed and disallowed outputs.
- TODO: Add checks for secret collection, real-brand impersonation, and unsafe links.
- TODO: Require a human review status before export.
- Deliverable: Prompt governance document plus automated test suite.

## Milestone 4: Durable Storage And Retention

- TODO: Replace JSONL logs with SQLite for class demos or PostgreSQL for team deployment.
- TODO: Add migrations for campaigns, drafts, approvals, and click events.
- TODO: Add retention settings for logs and generated content.
- TODO: Document what data is stored and why.
- Deliverable: Database-backed prototype with retention policy.

## Milestone 5: Training Links And Analytics

- TODO: Replace random URL tokens with signed, expiring tokens.
- TODO: Add campaign IDs and anonymized recipient IDs.
- TODO: Record opens/clicks without collecting secrets.
- TODO: Build a dashboard for aggregate campaign outcomes.
- Deliverable: Safe analytics flow and dashboard.

## Milestone 6: Export And Review Packets

- TODO: Export reviewed drafts as `.eml`, HTML, and plain text.
- TODO: Export campaign review packets as CSV or PDF.
- TODO: Add a reviewer checklist to every export.
- TODO: Add warnings when a draft has unresolved safety findings.
- Deliverable: Exportable campaign package.

## Milestone 7: Deployment Hardening

- TODO: Add production settings for host, port, log path, allowed origins, and proxy headers.
- TODO: Add Windows Server deployment notes for IIS reverse proxy or NSSM service hosting.
- TODO: Add Ubuntu deployment notes for Nginx and systemd.
- TODO: Add a separate public liveness endpoint and authenticated readiness endpoint.
- Deliverable: Deployment runbook for Windows Server 2025 and Ubuntu 24.04 LTS.

## Milestone 8: Final Documentation

- TODO: Create an architecture diagram.
- TODO: Write a threat model for misuse, data leakage, and campaign approval bypass.
- TODO: Write a test plan covering unit, integration, UI, and deployment checks.
- TODO: Prepare a final report with ethical and legal constraints.
- Deliverable: Final semester report and presentation-ready demo.
